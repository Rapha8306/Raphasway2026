import 'package:flutter/material.dart';

class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});

  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  final controller = TextEditingController();
  final messages = <({bool user, String text})>[
    (
      user: false,
      text: 'Hallo, ich bin Olivia. Ich helfe dir beim Planen und Organisieren. '
          'In dieser Starter-Version arbeite ich noch ohne externe KI-Verbindung.',
    ),
  ];

  void send() {
    final value = controller.text.trim();
    if (value.isEmpty) return;

    setState(() {
      messages.add((user: true, text: value));
      messages.add((
        user: false,
        text: 'Danke. Diese Demo speichert deine Nachricht nicht. '
            'Für eine echte Antwort muss später ein geschütztes KI-Backend angebunden werden.',
      ));
    });
    controller.clear();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Olivia')),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: messages.length,
              itemBuilder: (context, index) {
                final message = messages[index];
                return Align(
                  alignment: message.user ? Alignment.centerRight : Alignment.centerLeft,
                  child: ConstrainedBox(
                    constraints: const BoxConstraints(maxWidth: 560),
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Text(message.text),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: controller,
                      onSubmitted: (_) => send(),
                      decoration: const InputDecoration(
                        hintText: 'Frage Olivia …',
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    onPressed: send,
                    icon: const Icon(Icons.send),
                    tooltip: 'Senden',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
