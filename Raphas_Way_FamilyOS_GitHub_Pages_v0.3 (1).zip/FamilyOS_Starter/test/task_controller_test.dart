import 'package:flutter_test/flutter_test.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:family_os/features/tasks/task_controller.dart';

void main() {
  test('Task can be toggled', () {
    final container = ProviderContainer();
    addTearDown(container.dispose);

    final first = container.read(taskProvider).first;
    container.read(taskProvider.notifier).toggle(first.id);

    expect(container.read(taskProvider).first.completed, isTrue);
  });
}
